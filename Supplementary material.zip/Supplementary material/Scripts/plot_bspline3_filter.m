%% Visualize 3rd-order B-spline filter kernel in the spatial and spectral domain

clearvars
close all
clc
format long g

PSI       = (0:0.0001:pi)';
R         = 6378.1363; %Earth's radius [km]

% Set window length
r_1       = 600;
r_2       = 1000;
r_3       = 1400;

% Calculate B-spline filter kernel in the spatial domain
h_1       = f_bspline3_iso_sp(PSI,r_1,'filter');
h_2       = f_bspline3_iso_sp(PSI,r_2,'filter');
h_3       = f_bspline3_iso_sp(PSI,r_3,'filter');

% Calculate B-spline filter kernel in the spectral domain
W_1       = f_bspline3_iso_sh(r_1,10000);
W_2       = f_bspline3_iso_sh(r_2,10000);
W_3       = f_bspline3_iso_sh(r_3,10000);

% Plot B-spline filter kernel in the spatial domain
figure
set(gcf, 'Position', get(0,'Screensize'),'PaperPositionMode','auto');
ax_1 = axes;
hold on
plot(PSI*R,h_1,'color','b','LineWidth',2);
plot(PSI*R,h_2,'color','r','LineWidth',2);
plot(PSI*R,h_3,'color','g','LineWidth',2);
hold off
legend({'$r = 600$ km','$r = 1000$ km','$r = 1400$ km'},'Location','NorthEast','Interpreter','LaTeX','FontSize',30)
xlabel('$R \psi$ [km]','Interpreter','LaTeX')
ylabel('$h (\psi)$','Interpreter','LaTeX')
xlim([0 1500])
axis square
box on
grid on
ax_1.TickLabelInterpreter = 'Latex';
set(gca,'LineWidth',2,'FontSize',30)

% Plot B-spline filter kernel in the spectral domain
figure
set(gcf, 'Position', get(0,'Screensize'),'PaperPositionMode','auto');
ax_1 = axes;
semilogy(0:10000,abs(W_1),'color','b','LineWidth',2);
hold on
semilogy(0:10000,abs(W_2),'color','r','LineWidth',2);
semilogy(0:10000,abs(W_3),'color','g','LineWidth',2);
hold off
legend({'$r = 600$ km','$r = 1000$ km','$r = 1400$ km'},'Location','NorthEast','Interpreter','LaTeX','FontSize',30)
xlabel('Degree $n$','Interpreter','LaTeX')
ylabel('$|H_{n}|$','Interpreter','LaTeX')
xlim([0 2000])
ylim([1e-10 1e-00])
axis square
box on
grid on
ax_1.TickLabelInterpreter = 'Latex';
set(gca,'LineWidth',2,'FontSize',30)

%% Visualize polynomial covariance functions in the spatial and spectral domain

clearvars
close all
clc

R             = 6378.1363; %Earth's radius [km]
PSI           = 0:0.0001:pi;

spherical_1   = f_cov_spherical_sh(4000,600/R,'r',32);
spherical_2   = f_cov_spherical_sh(4000,1400/R,'r',32);

askey_1       = f_cov_askey_sh(4000,600/R,3,'r',32);
askey_2       = f_cov_askey_sh(4000,600/R,2,'r',32);
askey_3       = f_cov_askey_sh(4000,1400/R,3,'r',32);
askey_4       = f_cov_askey_sh(4000,1400/R,2,'r',32);

c2_wendland_1 = f_cov_wendland2_sh(4000,600/R,5,'r',32);
c2_wendland_2 = f_cov_wendland2_sh(4000,600/R,4,'r',32);
c2_wendland_3 = f_cov_wendland2_sh(4000,1400/R,5,'r',32);
c2_wendland_4 = f_cov_wendland2_sh(4000,1400/R,4,'r',32);

c4_wendland_1 = f_cov_wendland4_sh(4000,600/R,7,'r',32);
c4_wendland_2 = f_cov_wendland4_sh(4000,600/R,6,'r',32);
c4_wendland_3 = f_cov_wendland4_sh(4000,1400/R,7,'r',32);
c4_wendland_4 = f_cov_wendland4_sh(4000,1400/R,6,'r',32);

%% Spherical

figure
set(gcf, 'Position', get(0,'Screensize'),'PaperPositionMode','auto');
ax_1 = axes;
hold on
h1 = plot(PSI*R,f_cov_spherical_sp(PSI,600/R),'color','b','LineWidth',2);
h2a = plot(PSI*R,f_cov_spherical_sp(PSI,1400/R),'color','r','LineWidth',2);
hold off
legend([h1,h2a],{'$r = 600$ km','$r = 1400$ km'},'Location','NorthEast','Interpreter','LaTeX','FontSize',30)
xlabel('$R \psi$ [km]','Interpreter','LaTeX')
ylabel('$C(\psi)$','Interpreter','LaTeX')
xlim([0 1500])
axis square
box on
grid on
ax_1.TickLabelInterpreter = 'Latex';
set(gca,'LineWidth',2,'FontSize',30)

figure
set(gcf, 'Position', get(0,'Screensize'),'PaperPositionMode','auto');
ax_1 = axes;
h1 = semilogy(0:4000,spherical_1,'color','b','LineWidth',2);
hold on
h2a = semilogy(0:4000,spherical_2,'color','r','LineWidth',2);
hold off
legend([h1,h2a],{'$r = 600$ km','$r = 1400$ km'},'Location','NorthEast','Interpreter','LaTeX','FontSize',30)
xlabel('Degree $n$','Interpreter','LaTeX')
ylabel('$\Gamma_{n}$','Interpreter','LaTeX')
xlim([0 4000])
ylim([1e-20 1e-02])
axis square
box on
grid on
ax_1.TickLabelInterpreter = 'Latex';
set(gca,'LineWidth',2,'FontSize',30,'YTick',[1e-20 1e-14 1e-8 1e-2])

%% Askey

figure
set(gcf, 'Position', get(0,'Screensize'),'PaperPositionMode','auto');
ax_1 = axes;
hold on
h2a = plot(PSI*R,f_cov_askey_sp(PSI,600/R,3),'color','r','LineWidth',2);
h1 = plot(PSI*R,f_cov_askey_sp(PSI,600/R,2),'color','b','LineWidth',2);
h4 = plot(PSI*R,f_cov_askey_sp(PSI,1400/R,3),'color','m','LineWidth',2);
h3 = plot(PSI*R,f_cov_askey_sp(PSI,1400/R,2),'color','g','LineWidth',2);
hold off
legend([h1,h2a,h3,h4],{'$r = 600$ km, $\tau = 2$','$r = 600$ km, $\tau = 3$','$r = 1400$ km, $\tau = 2$','$r = 1400$ km, $\tau = 3$'},'Location','NorthEast','Interpreter','LaTeX','FontSize',30)
xlabel('$R \psi$ [km]','Interpreter','LaTeX')
ylabel('$C(\psi)$','Interpreter','LaTeX')
xlim([0 1500])
axis square
box on
grid on
ax_1.TickLabelInterpreter = 'Latex';
set(gca,'LineWidth',2,'FontSize',30)

figure
set(gcf, 'Position', get(0,'Screensize'),'PaperPositionMode','auto');
ax_1 = axes;
h2a = semilogy(0:4000,askey_1,'color','r','LineWidth',2);
hold on
h1 = semilogy(0:4000,askey_2,'color','b','LineWidth',2);
h4 = semilogy(0:4000,askey_3,'color','m','LineWidth',2);
h3 = semilogy(0:4000,askey_4,'color','g','LineWidth',2);
hold off
legend([h1,h2a,h3,h4],{'$r = 600$ km, $\tau = 2$','$r = 600$ km, $\tau = 3$','$r = 1400$ km, $\tau = 2$','$r = 1400$ km, $\tau = 3$'},'Location','NorthEast','Interpreter','LaTeX','FontSize',30)
xlabel('Degree $n$','Interpreter','LaTeX')
ylabel('$\Gamma_{n}$','Interpreter','LaTeX')
xlim([0 4000])
ylim([1e-20 1e-02])
axis square
box on
grid on
ax_1.TickLabelInterpreter = 'Latex';
set(gca,'LineWidth',2,'FontSize',30,'YTick',[1e-20 1e-14 1e-8 1e-2])

%% C^2-Wendland

figure
set(gcf, 'Position', get(0,'Screensize'),'PaperPositionMode','auto');
ax_1 = axes;
hold on
h2a = plot(PSI*R,f_cov_wendland2_sp(PSI,600/R,5),'color','r','LineWidth',2);
h1 = plot(PSI*R,f_cov_wendland2_sp(PSI,600/R,4),'color','b','LineWidth',2);
h4 = plot(PSI*R,f_cov_wendland2_sp(PSI,1400/R,5),'color','m','LineWidth',2);
h3 = plot(PSI*R,f_cov_wendland2_sp(PSI,1400/R,4),'color','g','LineWidth',2);
hold off
legend([h1,h2a,h3,h4],{'$r = 600$ km, $\tau = 4$','$r = 600$ km, $\tau = 5$','$r = 1400$ km, $\tau = 4$','$r = 1400$ km, $\tau = 5$'},'Location','NorthEast','Interpreter','LaTeX','FontSize',30)
xlabel('$R \psi$ [km]','Interpreter','LaTeX')
ylabel('$C(\psi)$','Interpreter','LaTeX')
xlim([0 1500])
axis square
box on
grid on
ax_1.TickLabelInterpreter = 'Latex';
set(gca,'LineWidth',2,'FontSize',30)

figure
set(gcf, 'Position', get(0,'Screensize'),'PaperPositionMode','auto');
ax_1 = axes;
h2a = semilogy(0:4000,c2_wendland_1,'color','r','LineWidth',2);
hold on
h1 = semilogy(0:4000,c2_wendland_2,'color','b','LineWidth',2);
h4 = semilogy(0:4000,c2_wendland_3,'color','m','LineWidth',2);
h3 = semilogy(0:4000,c2_wendland_4,'color','g','LineWidth',2);
hold off
legend([h1,h2a,h3,h4],{'$r = 600$ km, $\tau = 4$','$r = 600$ km, $\tau = 5$','$r = 1400$ km, $\tau = 4$','$r = 1400$ km, $\tau = 5$'},'Location','NorthEast','Interpreter','LaTeX','FontSize',30)
xlabel('Degree $n$','Interpreter','LaTeX')
ylabel('$\Gamma_{n}$','Interpreter','LaTeX')
xlim([0 4000])
ylim([1e-20 1e-02])
axis square
box on
grid on
ax_1.TickLabelInterpreter = 'Latex';
set(gca,'LineWidth',2,'FontSize',30,'YTick',[1e-20 1e-14 1e-8 1e-2])

%% C^4-Wendland

figure
set(gcf, 'Position', get(0,'Screensize'),'PaperPositionMode','auto');
ax_1 = axes;
hold on
h2a = plot(PSI*R,f_cov_wendland4_sp(PSI,600/R,7),'color','r','LineWidth',2);
h1 = plot(PSI*R,f_cov_wendland4_sp(PSI,600/R,6),'color','b','LineWidth',2);
h4 = plot(PSI*R,f_cov_wendland4_sp(PSI,1400/R,7),'color','m','LineWidth',2);
h3 = plot(PSI*R,f_cov_wendland4_sp(PSI,1400/R,6),'color','g','LineWidth',2);
hold off
legend([h1,h2a,h3,h4],{'$r = 600$ km, $\tau = 6$','$r = 600$ km, $\tau = 7$','$r = 1400$ km, $\tau = 6$','$r = 1400$ km, $\tau = 7$'},'Location','NorthEast','Interpreter','LaTeX','FontSize',30)
xlabel('$R \psi$ [km]','Interpreter','LaTeX')
ylabel('$C(\psi)$','Interpreter','LaTeX')
xlim([0 1500])
axis square
box on
grid on
ax_1.TickLabelInterpreter = 'Latex';
set(gca,'LineWidth',2,'FontSize',30)

figure
set(gcf, 'Position', get(0,'Screensize'),'PaperPositionMode','auto');
ax_1 = axes;
h2a = semilogy(0:4000,c4_wendland_1,'color','r','LineWidth',2);
hold on
h1 = semilogy(0:4000,c4_wendland_2,'color','b','LineWidth',2);
h4 = semilogy(0:4000,c4_wendland_3,'color','m','LineWidth',2);
h3 = semilogy(0:4000,c4_wendland_4,'color','g','LineWidth',2);
hold off
legend([h1,h2a,h3,h4],{'$r = 600$ km, $\tau = 6$','$r = 600$ km, $\tau = 7$','$r = 1400$ km, $\tau = 6$','$r = 1400$ km, $\tau = 7$'},'Location','NorthEast','Interpreter','LaTeX','FontSize',30)
xlabel('Degree $n$','Interpreter','LaTeX')
ylabel('$\Gamma_{n}$','Interpreter','LaTeX')
xlim([0 4000])
ylim([1e-20 1e-02])
axis square
box on
grid on
ax_1.TickLabelInterpreter = 'Latex';
set(gca,'LineWidth',2,'FontSize',30,'YTick',[1e-20 1e-14 1e-8 1e-2])

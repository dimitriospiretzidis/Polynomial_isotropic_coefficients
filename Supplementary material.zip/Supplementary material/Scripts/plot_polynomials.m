%% Visualize monomial and polynomial functions in the spatial and spectral domain

clearvars
close all
clc

% Set parameters
m      = 10;
n      = 200;
PSI    = (0:0.0001:pi)';
psi_1  = 4*pi/9;
psi_2  = 6*pi/9;
psi_3  = 52*pi/180;
psi_4  = 120*pi/180;

% Calculate monomial coefficients
W_nm_1 = f_ltpsim(psi_1,psi_2,n,m,'all');
W_nm_2 = f_ltpsim(psi_3,psi_4,n,m,'all');

% Calculate 5-th order polynomial
f      = PSI.^5 - 7.5*PSI.^4 + 21.875*PSI.^3 - 30.938*PSI.^2 + 21.129*PSI - 5.537;

% Calculate spherical harmonic coefficients of 5-th order polynomial
F_n    = W_nm_2(:,6) - 7.5*W_nm_2(:,5) + 21.875*W_nm_2(:,4) - 30.938*W_nm_2(:,3) + 21.129*W_nm_2(:,2) - 5.537*W_nm_2(:,1);

% Calculate reconstructed 5-th order polynomial
f_rec  = f_ilegendre_tra(F_n,PSI);

% Plot monomials up to order 3 in the spectral domain
figure
set(gcf,'Position', get(0,'Screensize'),'PaperPositionMode','auto')
ax_1 = axes;
h1   = semilogy(0:n,abs(W_nm_1(:,4)),'color','g','LineWidth',2);
hold on
h2   = semilogy(0:n,abs(W_nm_1(:,3)),'color','r','LineWidth',2);
h3   = semilogy(0:n,abs(W_nm_1(:,2)),'color','b','LineWidth',2);
hold off
legend([h3,h2,h1],{'$m = 1$','$m = 2$','$m = 3$'},'Location','NorthEast','Interpreter','LaTeX','FontSize',30)
xlabel('Degree $n$','Interpreter','LaTeX')
ylabel('$|\Psi_{n,m}^{(I)}|$','Interpreter','LaTeX')
xlim([0 200])
axis square
box on
grid on
ax_1.TickLabelInterpreter = 'Latex';
set(gca,'LineWidth',2,'FontSize',30')

% Plot monomials up to order 3 in the spatial domain
figure
set(gcf,'Position', get(0,'Screensize'),'PaperPositionMode','auto')
ax_2 = axes;
hold on
plot(PSI*180/pi,PSI.^3,'color','#96f97b','LineWidth',2);
plot(PSI*180/pi,PSI.^2,'color','#ffd1df','LineWidth',2);
plot(PSI*180/pi,PSI,'color','#95d0fc','LineWidth',2);
plot(PSI*180/pi,f_ilegendre_tra(W_nm_1(:,4),PSI),'color','g','LineWidth',2);
plot(PSI*180/pi,f_ilegendre_tra(W_nm_1(:,3),PSI),'color','r','LineWidth',2);
plot(PSI*180/pi,f_ilegendre_tra(W_nm_1(:,2),PSI),'color','b','LineWidth',2);
hold off
xlabel('$\psi \ [^{\circ}]$','Interpreter','LaTeX')
ylabel('$\psi^{m} \ [\mathrm{rad}]$','Interpreter','LaTeX')
xlim([0 180])
ylim([-1 10])
axis square
box on
grid on
ax_2.TickLabelInterpreter = 'Latex';
set(gca,'LineWidth',2,'FontSize',30','XTick',(0:45:180))
set(ax_2,'Position',get(ax_1,'Position'))

% Plot 5-th order polynomial in the spectral domain
figure
set(gcf,'Position', get(0,'Screensize'),'PaperPositionMode','auto')
ax_4 = axes;
semilogy(0:n,abs(F_n),'color','b','LineWidth',2);
xlabel('Degree $n$','Interpreter','LaTeX')
ylabel('$|S_{n}^{(I)}|$','Interpreter','LaTeX')
xlim([0 200])
axis square
box on
grid on
ax_4.TickLabelInterpreter = 'Latex';
set(gca,'LineWidth',2,'FontSize',30')
set(ax_4,'Position',get(ax_1,'Position'))

% Plot 5-th order polynomial in the spatial domain
figure
set(gcf,'Position', get(0,'Screensize'),'PaperPositionMode','auto')
ax_3 = axes;
hold on
plot(PSI*180/pi,f,'color','#95d0fc','LineWidth',2);
plot(PSI*180/pi,f_rec,'color','b','LineWidth',2);
hold off
xlabel('$\psi \ [^{\circ}]$','Interpreter','LaTeX')
ylabel('$s (\psi) \ [\mathrm{rad}]$','Interpreter','LaTeX')
xlim([0 180])
ylim([-0.05 0.05])
axis square
box on
grid on
ax_3.TickLabelInterpreter = 'Latex';
set(gca,'LineWidth',2,'FontSize',30','XTick',(0:45:180),'YTick',(-0.05:0.02:0.05))
set(ax_3,'Position',get(ax_1,'Position'))

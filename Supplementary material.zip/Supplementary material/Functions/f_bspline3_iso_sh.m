function [W_n] = f_bspline3_iso_sh(s_0,n_max)
%%
% F_BSPLINE3_ISO_SH calculates the spherical harmonic coefficients of an
% isotropic 3rd-order B-spline filter. For more information, see:
%
% Piretzidis D, Kotsakis C, Mertikas SP, Sideris MG: Spherical harmonic
%      coefficients of isotropic polynomial functions with applications to
%      gravity field modeling
%
% HOW: [W_n] = f_bspline3_iso_sh(s_0,n_max)
%
% Input:  s_0             [1 x 1] filter length [km].
%
%         n_max           [1 x 1] maximum degree.
%
% Output: W_n             [n x 1] filter coefficients.
%
% Dimitrios Piretzidis, Space Geomatica P.C.
% 2022

% required m-files: f_ltpsim.m

%% Revision history

%% Remarks

%% Input check

if nargin ~= 2; error('Wrong number of input arguments.'); end

if ~isscalar(s_0)
    error('<s_0> should be scalar.')
end

if ~isscalar(n_max)
    error('<n_max> should be scalar.')
end

%% Start the algorithm

% Define constants
R     = 6378.1363; %Earth's radius [km]
psi_0 = s_0/R;     %Filter length [rad]

% Calculate spherical harmonic coefficients of all monomials up to order 2
PSI_1 = f_ltpsim(0,psi_0/3,n_max,2,'all');
PSI_2 = f_ltpsim(psi_0/3,psi_0,n_max,2,'all');

% Calculate window average
w_bar = 3*(2 + (psi_0^2)/3 - 3*cos(psi_0/3) + cos(psi_0))/(2*psi_0^2);

% Calculate B-spline filter spherical harmonic coefficients
W_n   = (PSI_1(:,1) - (3/psi_0^2)*PSI_1(:,3) + (3/(2*psi_0^2))*PSI_2(:,3) - (3/psi_0)*PSI_2(:,2) + (3/2)*PSI_2(:,1))/w_bar;

end

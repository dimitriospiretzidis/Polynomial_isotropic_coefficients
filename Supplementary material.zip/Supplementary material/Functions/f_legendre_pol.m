function [P_n] = f_legendre_pol(n,t,out_deg,vpa_dig)
%%
% F_LEGENDRE_POL calculates the Legendre polynomial using Bonnet's formula.
%
% HOW: [P_n] = f_legendre_pol(n,t,out_deg,vpa_dig)
%      [P_n] = f_legendre_pol(n,t,out_deg)
%      [P_n] = f_legendre_pol(n,t)
%
% Input:  n                 [1 x 1] degree.
%
%         t                 [k x m] input argument. Usually is cos(theta)
%                                   or sin(phi).
%
%         out_deg                   output degrees. Options:
%                                   -'current' (default) returns only the
%                                              polynomial of degree <n>.
%                                   -'all'     returns the polynomials from
%                                              degree 0 to <n>.
%
%         vpa_dig           [1 x 1] number of significant digits for
%                                   variable-precision arithmetic.
%
% Output: P_n               [k x m] Legendre polynomial.
%              or [k x m x (n + 1)]
%
% Dimitrios Piretzidis, Department of Geomatics Engineering UofC
% 31/12/2014

% required m-files: none

%% Revision history

%03/04/2020 Dimitrios Piretzidis: Legendre polynomials of negative degrees
%                                 are added (P_{-n-1} = P_n).

%% Remarks

%% Input check

if nargin < 2 || nargin > 5; error('Wrong number of input arguments.'); end
if nargin == 2             ; out_deg = 'current'; vpa_dig = NaN       ; end
if nargin == 3             ; vpa_dig = NaN                            ; end

if ~isscalar(n)
    error('<n> should be scalar.')
end

if strcmp(out_deg,'current') == 0 && strcmp(out_deg,'all') == 0
    error('<out_deg> should be one of the following: ''current'', ''all''.')
end

if ~isscalar(vpa_dig)
    error('<vpa_dig> should be scalar.')
end

%% Start the algorithm

%Treat negative degree
if n < 0
    
    n                    = abs(n) - 1;
    flag_n               = 1;
    
else
    
    flag_n               = 0;
    
end

%Initialize the output matrix
[i_max,j_max]            = size(t);

%Set up precision
if isnan(vpa_dig)
    
    P_n                  = zeros(i_max,j_max,n + 1);
    
else
    
    %Set new precision
    digits(vpa_dig)
    
    P_n                  = vpa(zeros(i_max,j_max,n + 1));
    
end

%Initialize P_{0}
P_n(:,:,1)               = 1;

%Initialize P_{1}
if n > 0
    
    P_n(:,:,2)           = t;
    
end

%Calculate P_{n}
for i = 2:n
    
    P_n(:,:,i + 1)       = ((2*i - 1).*t.*P_n(:,:,i) - (i - 1).*P_n(:,:,i - 1))./i;
    
end

if strcmp(out_deg,'current')
    
    P_n                  = P_n(:,:,n + 1);
    
else
    
    if flag_n == 1
        
        %Reverse order for negative degrees
        P_n              = flip(P_n,3);
        
        %Add P_{0} at the end
        P_n(:,:,end + 1) = P_n(:,:,end);
        
    end
    
end

P_n                      = squeeze(P_n);

end

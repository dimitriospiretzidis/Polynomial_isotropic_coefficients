function [C] = f_cov_spherical_sp(psi,psi_0)
%%
% F_COV_SPHERICAL_SP returns the spherical covariance function in the
% spatial domain. For more information, see: 
%
% D Piretzidis, C Kotsakis, SP Mertikas and MG Sideris (2021) Spherical
%      harmonic coefficients of isotropic polynomial functions with
%      applications to gravity field modeling
%
% HOW: [C] = f_cov_spherical_sp(psi,psi_0)
%
% Input:  psi             [n x m] spherical distance [rad]. Should be:
%                                 0 <= psi <= pi.
%
%         psi_0           [1 x 1] support length [rad].
%
% Output: C               [n x m] spatial covariance.
%
% Dimitrios Piretzidis, Department of Mineral Resources Engineering, TUC
% 03/10/2021

% required m-files: none

%% Revision history

%% Remarks

%% Input check

if nargin ~= 2; error('Wrong number of input arguments.'); end

if ~isscalar(psi_0) || max(psi_0 <= 0)
    error('<psi_0> should be a scalar greater than zero.')
end

%% Start the algorithm

C              = 1 - 3*psi/(2*psi_0) + (psi.^3)/(2*psi_0^3);
C(psi > psi_0) = 0;

end

function [w_psi] = f_bspline3_iso_sp(PSI,s_0,fun)
%%
% F_BSPLINE3_ISO_SP calculates the window function and filter kernel of
% an isotropic 3rd-order B-spline window. For more information, see:
%
% Piretzidis D, Kotsakis C, Mertikas SP, Sideris MG: Spherical harmonic
%      coefficients of isotropic polynomial functions with applications to
%      gravity field modeling
%
% HOW: [w_psi] = f_bspline3_iso_sp(PSI,s_0,fun)
%
% Input:  PSI             [n x m] spherical distance [rad]. Should be:
%                                 0 <= psi <= pi.
%
%         s_0             [1 x 1] window length [km].
%
%         fun                     output function. Options:
%                                 - 'window' window function
%                                 - 'filter' filter kernel
%
% Output: w_psi           [n x m] output function.
%
% Dimitrios Piretzidis, Space Geomatica P.C.
% 2022

% required m-files: none

%% Revision history

%% Remarks

%% Input check

if nargin ~= 3; error('Wrong number of input arguments.'); end

if ~isscalar(s_0)
    error('<s_0> should be scalar.')
end

if ~strcmp(fun,'window') && ~strcmp(fun,'filter')
    error('<fun> should be ''window'' or ''filter''.')
end

%% Start the algorithm

% Define constants
R            = 6378.1363; %Earth's radius [km]
psi_0        = s_0/R;       %Window length [rad]

% Calculate window function
idx_1        = PSI <= psi_0/3;
idx_2        = PSI > psi_0/3 & PSI <= psi_0;
w_psi        = zeros(size(PSI));
w_psi(idx_1) = 1 - 3*PSI(idx_1).^2/(psi_0^2);
w_psi(idx_2) = 3*PSI(idx_2).^2/(2*psi_0^2) - 3*PSI(idx_2)/psi_0 + 3/2;

if strcmp(fun,'filter')
    
    % Calculate window average
    w_bar    = (6 + psi_0^2 - 9*cos(psi_0/3) + 3*cos(psi_0))/(2*psi_0^2);
    
    % Calculate filter kernel
    w_psi    = w_psi/w_bar;
    
end

end

function [G] = f_cov_spherical_sh(n_max,psi_0,method,method_par)
%%
% F_COV_SPHERICAL_SH returns the spherical harmonic coefficients of the
% spherical covariance model. For more information, see:
%
% Piretzidis D, Kotsakis C, Mertikas SP, Sideris MG: Spherical harmonic
%      coefficients of isotropic polynomial functions with applications to
%      gravity field modeling
%
% HOW: [G] = f_cov_spherical_sh(n_max,psi_0,method,method_par)
%
% Input:  n_max           [1 x 1] maximum degree.
%
%         psi_0           [1 x 1] support length [rad].
%
%         method                  calculation method. Options:
%                                 -'r'       (default) recurrent.
%                                 -'n'                 numerical.
%                                 -'h'                 hybrid.
%                                 -'e'                 extended precision.
%
%         method_par      [1 x 1] method-specific parameter. For the
%                                 following methods, it denotes:
%                                 -'h' maximum degree of coefficients
%                                      calculated using numerical
%                                      integration. Default is 2.
%                                 -'e' number of significant digits.
%
% Output: G               [n x 1] spherical harmonic coefficients.
%
% Dimitrios Piretzidis, Space Geomatica P.C.
% 2022

% required m-files: f_ltpsim.m

%% Revision history

%% Remarks

%% Input check

if nargin < 2 || nargin > 4         ; error('Wrong number of input arguments.'); end
if nargin == 3 && strcmp(method,'r'); method_par = []                          ; end
if nargin == 3 && strcmp(method,'n'); method_par = n_max                       ; end
if nargin == 3 && strcmp(method,'h'); method_par = 1                           ; end
if nargin == 2                      ; method     = 'r'; method_par = []        ; end

if ~isscalar(n_max)
    error('<n_max> should be a scalar.')
end

if ~isscalar(psi_0)
    error('<psi_0> should be a scalar.')
end

if psi_0 <= 0
    warning('<psi_0> should be greater than 0.')
end

if strcmp(method,'r') == 0 && strcmp(method,'n') == 0 && strcmp(method,'h') == 0 && strcmp(method,'e') == 0
    error('<out_m> should be one of the following: ''r'', ''n'', ''h'', ''e''.')
end

if strcmp(method,'h') == 1 && method_par ~= floor(method_par)
    error('<method_par> should be integer.')
end

if strcmp(method,'h') == 1 && method_par < 1
    error('<method_par> should be greater than 0.')
end

if strcmp(method,'e') == 1 && method_par ~= floor(method_par)
    error('<method_par> should be integer.')
end

%% Start the algorithm

% Calculate spherical harmonic coefficients of monomials up to order 3
PSI_nm = f_ltpsim(0,min(psi_0,pi),n_max,3,'all',method,method_par);

% Calculate covariance function coefficients
G      = PSI_nm(:,1) - 3*PSI_nm(:,2)/(2*psi_0) + PSI_nm(:,4)/(2*psi_0^3);

end

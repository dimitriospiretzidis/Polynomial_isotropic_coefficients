function [C] = f_cov_wendland4_sp(psi,psi_0,t)
%%
% F_COV_WENDLAND4_SP returns the C^4-Wendland covariance function in the
% spatial domain. For more information, see:
%
% Piretzidis D, Kotsakis C, Mertikas SP, Sideris MG: Spherical harmonic
%      coefficients of isotropic polynomial functions with applications to
%      gravity field modeling
%
% HOW: [C] = f_cov_wendland4_sp(psi,psi_0,t)
%
% Input:  psi             [n x m] spherical distance [rad]. Should be:
%                                 0 <= psi <= pi.
%
%         psi_0           [1 x 1] support length [rad].
%
%         t               [1 x 1] shape parameter.
%
% Output: C               [n x m] spatial covariance.
%
% Dimitrios Piretzidis, Space Geomatica P.C.
% 2022

% required m-files: none

%% Revision history

%% Remarks

%% Input check

if nargin ~= 3; error('Wrong number of input arguments.'); end

if ~isscalar(psi_0) || max(psi_0 <= 0) || max(psi_0 > pi)
    error('<psi_0> should be a scalar in (0,pi].')
end

if ~isscalar(t) || t ~= floor(t)
    error('<t> should be a scalar integer.')
end

if t < 6
    warning('<t> should be greater than or equal to 6.')
end

%% Start the algorithm

C              = (1 + t*psi/psi_0 + ((t^2 - 1)/(3*psi_0^2))*psi.^2).*(1 - psi/psi_0).^t;
C(psi > psi_0) = 0;

end

function [W_nm] = f_ltpsim(psi_1,psi_2,n_max,m,out_m,method,method_par)
%%
% F_LTPSIM calculates the short-space Legendre transform of the monomial
% psi^m. For more information, see:
%
% Piretzidis D, Kotsakis C, Mertikas SP, Sideris MG: Spherical harmonic
%      coefficients of isotropic polynomial functions with applications to
%      gravity field modeling
%
% HOW: [W_n] = f_ltpsim(psi_1,psi_2,n_max,m,out_m,method,method_par)
%
% Input:  psi_1           [1 x 1] lower integration limit (in rad).
%
%         psi_2           [1 x 1] upper integration limit (in rad).
%
%         n_max           [1 x 1] maximum harmonic degree.
%
%         m               [1 x 1] monomial order.
%
%         out_m                   output monomial. Options:
%                                 -'current' (default) returns only the
%                                            coefficients of monomial of
%                                            order <m>.
%                                 -'all'     returns the coefficients of
%                                            monomials of order 0 to <m>.
%
%         method                  calculation method. Options:
%                                 -'r'       (default) recurrent.
%                                 -'n'                 numerical.
%                                 -'h'                 hybrid.
%                                 -'e'                 extended precision.
%
%         method_par      [1 x 1] method-specific parameter. For the
%                                 following methods, it denotes:
%                                 -'h' maximum degree of coefficients
%                                      calculated using numerical
%                                      integration. Default is 2.
%                                 -'e' number of significant digits.
%
% Output: W_n             [n x 1] coefficients of Legendre transform.
%
% Dimitrios Piretzidis, Space Geomatica P.C.
% 2022

% required m-files: f_legendre_pol.m, lgwt.m

%% Revision history

%% Remarks

%% Input check

if nargin < 4 || nargin > 7         ; error('Wrong number of input arguments.'); end
if nargin == 6 && strcmp(method,'h'); method_par = 1                           ; end
if nargin == 6 && strcmp(method,'n'); method_par = n_max                       ; end
if nargin == 5                      ; method = 'r'                             ; end
if nargin == 4                      ; method = 'r'; out_m = 'current'          ; end

if ~isscalar(psi_1) || ~isscalar(psi_2) || ~isscalar(n_max) || ~isscalar(m)
    error('Input arguments should be scalars.')
end

if strcmp(out_m,'current') == 0 && strcmp(out_m,'all') == 0
    error('<out_m> should be one of the following: ''current'', ''all''.')
end

if strcmp(method,'r') == 0 && strcmp(method,'n') == 0 && strcmp(method,'h') == 0 && strcmp(method,'e') == 0
    error('<out_m> should be one of the following: ''r'', ''n'', ''h'', ''e''.')
end

if strcmp(method,'h') == 1 && method_par ~= floor(method_par)
    error('<method_par> should be integer.')
end

if strcmp(method,'h') == 1 && method_par < 1
    error('<method_par> should be greater than 0.')
end

if strcmp(method,'e') == 1 && method_par ~= floor(method_par)
    error('<method_par> should be integer.')
end

%% Start the algorithm

%Calculation of nodes and weights for numerical integration using
%Gauss-Legendre quadrature
if strcmp(method,'n') || strcmp(method,'h')
    
    % Nodes and weights
    [a,w_i]                       = lgwt(n_max + 4000,-1,1);
    
    % Normalized nodes
    a_i                           = (a.*(psi_2 - psi_1) + (psi_2 + psi_1))/2;
    
    % Auxiliary variables
    cos_a_i                       = cos(a_i);
    sin_a_i                       = sin(a_i);
    P_n                           = f_legendre_pol(method_par,cos_a_i,'all');
    
end

if strcmp(method,'e') == 1
    
    % Set new precision
    digits(method_par)
    
    psi_1                         = vpa(psi_1);
    psi_2                         = vpa(psi_2);
    
    % Initialize variables
    W_nm                          = vpa(zeros(n_max + 1,m + 1));
    B_nm1                         = vpa(zeros(n_max + 1,m + 1));
    B_nm2                         = vpa(zeros(n_max + 1,m + 1));
    D_nm1                         = vpa(zeros(n_max + 1,m + 1));
    D_nm2                         = vpa(zeros(n_max + 1,m + 1));
    B_nm                          = vpa(zeros(n_max + 1,m + 1));
    D_nm                          = vpa(zeros(n_max + 1,m + 1));
    
else
    
    % Initialize variables
    W_nm                          = zeros(n_max + 1,m + 1);
    B_nm1                         = zeros(n_max + 1,m + 1);
    B_nm2                         = zeros(n_max + 1,m + 1);
    D_nm1                         = zeros(n_max + 1,m + 1);
    D_nm2                         = zeros(n_max + 1,m + 1);
    B_nm                          = zeros(n_max + 1,m + 1);
    D_nm                          = zeros(n_max + 1,m + 1);
    
end

% Define auxiliary variables
y1                                = cos(psi_1);
u1                                = sin(psi_1);
y2                                = cos(psi_2);
if psi_2 == pi
    u2                            = 0;
else
    u2                            = sin(psi_2);
end

% Initialize B_{n,m}, D_{n,m} and W_{n,m}
B_nm1(1,1)                        = (1 - y1)/2;
B_nm2(1,1)                        = (1 - y2)/2;
B_nm1(1,2)                        = psi_1*(1 - y1)/2;
B_nm2(1,2)                        = psi_2*(1 - y2)/2;
B_nm1(2,1)                        = u1^2/4;
B_nm2(2,1)                        = u2^2/4;
B_nm1(2,2)                        = psi_1*u1^2/4;
B_nm2(2,2)                        = psi_2*u2^2/4;

D_nm1(1,1)                        = 0;
D_nm2(1,1)                        = 0;
D_nm1(1,2)                        = u1*(1 - y1)/2;
D_nm2(1,2)                        = u2*(1 - y2)/2;
D_nm1(2,1)                        = 0;
D_nm2(2,1)                        = 0;
D_nm1(2,2)                        = 3*u1^3/4;
D_nm2(2,2)                        = 3*u2^3/4;

W_nm(1,1)                         = (y1 - y2)/2;
W_nm(1,2)                         = (u2 - u1 - psi_2*y2 + psi_1*y1)/2;
W_nm(2,1)                         = (cos(2*psi_1) - cos(2*psi_2))/8;
W_nm(2,2)                         = (sin(2*psi_2) - sin(2*psi_1) - 2*psi_2*cos(2*psi_2) + 2*psi_1*cos(2*psi_1))/16;

% Calculate B_{0,m}, B_{1,m}, D_{0,m}, D_{1,m}, W_{0,m} and W_{1,m}
for i = 2:m
    
    B_nm1(1:2,i + 1)              = psi_1*B_nm1(1:2,i);
    B_nm2(1:2,i + 1)              = psi_2*B_nm2(1:2,i);
    
    D_nm1(1:2,i + 1)              = (i/(i - 1))*psi_1*D_nm1(1:2,i);
    D_nm2(1:2,i + 1)              = (i/(i - 1))*psi_2*D_nm2(1:2,i);
    
    if strcmp(method,'r') == 1 || strcmp(method,'e') == 1
        
        W_nm(1,i + 1)             = -i*(i - 1)*W_nm(1,i - 1)   + ((psi_2^(i - 1))*(i*u2 - psi_2*y2)...
            -  (psi_1^(i - 1))*(i*u1 - psi_1*y1))/2;
        W_nm(2,i + 1)             = -i*(i - 1)*W_nm(2,i - 1)/4 + ((psi_2^(i - 1))*(i*sin(2*psi_2) - 2*psi_2*cos(2*psi_2))...
            -  (psi_1^(i - 1))*(i*sin(2*psi_1) - 2*psi_1*cos(2*psi_1)))/16;
        
    else
        
        % Evaluate integrand at nodes
        f_1                       = (a_i.^i).*P_n(:,0 + 1).*sin_a_i;
        f_2                       = (a_i.^i).*P_n(:,1 + 1).*sin_a_i;
        
        % Numerical integration using Gauss-Legendre quadrature
        W_nm(1,i + 1)             = (psi_2 - psi_1)*sum(w_i.*f_1)/4;
        W_nm(2,i + 1)             = (psi_2 - psi_1)*sum(w_i.*f_2)/4;
        
        % Numerical integration using Gauss-Kronrod adaptive quadrature
        %W_nm(1,i + 1)             = (1/2)*quadgk(@(psi) (psi.^i).*f_legendre_pol(0,cos(psi),'current').*sin(psi),psi_1,psi_2);
        %W_nm(2,i + 1)             = (1/2)*quadgk(@(psi) (psi.^i).*f_legendre_pol(1,cos(psi),'current').*sin(psi),psi_1,psi_2);
        
    end
    
end

B_nm(1:2,1:m + 1)                 = B_nm2(1:2,1:m + 1) - B_nm1(1:2,1:m + 1);
D_nm(1:2,1:m + 1)                 = D_nm2(1:2,1:m + 1) - D_nm1(1:2,1:m + 1);

% Calculate B_{n,m}, D_{n,m} and W_{n,m}
for j = 0:m
    
    for i = 2:n_max
        
        B_nm1(i + 1,j + 1)        = ((2*i - 1)*y1*B_nm1(i,j + 1) - (i - 2)*B_nm1(i - 1,j + 1))/(i + 1);
        B_nm2(i + 1,j + 1)        = ((2*i - 1)*y2*B_nm2(i,j + 1) - (i - 2)*B_nm2(i - 1,j + 1))/(i + 1);
        
        D_nm1(i + 1,j + 1)        = (2*i + 1)*(y1*D_nm1(i,j + 1) - ((i - 2)/(2*i - 3))*D_nm1(i - 1,j + 1))/(i + 1);
        D_nm2(i + 1,j + 1)        = (2*i + 1)*(y2*D_nm2(i,j + 1) - ((i - 2)/(2*i - 3))*D_nm2(i - 1,j + 1))/(i + 1);
        
        B_nm(i + 1,j + 1)         = B_nm2(i + 1,j + 1) - B_nm1(i + 1,j + 1);
        D_nm(i + 1,j + 1)         = D_nm2(i + 1,j + 1) - D_nm1(i + 1,j + 1);
        
        if strcmp(method,'r') == 1 || strcmp(method,'e') == 1 || (strcmp(method,'h') == 1 && i > method_par)
            
            if j == 0 || j == 1
                
                W_nm(i + 1,j + 1) = (((i - 2)^2)*W_nm(i - 1,j + 1) + ((i + 1)^2)*B_nm(i + 1,j + 1) - ((i - 2)^2)*B_nm(i - 1,j + 1) - D_nm(i,j + 1))/((i + 1)^2);
                
            else
                
                W_nm(i + 1,j + 1) = (((i - 2)^2)*W_nm(i - 1,j + 1) + ((i + 1)^2)*B_nm(i + 1,j + 1) - ((i - 2)^2)*B_nm(i - 1,j + 1) - D_nm(i,j + 1) + j*(j - 1)*(W_nm(i - 1,j - 1) - W_nm(i + 1,j - 1)))/((i + 1)^2);
                
            end
            
        else
            
            % Evaluate integrand at nodes
            f_i                   = (a_i.^j).*P_n(:,i + 1).*sin_a_i;
            
            % Numerical integration using Gauss-Legendre quadrature
            W_nm(i + 1,j + 1)     = (psi_2 - psi_1)*sum(w_i.*f_i)/4;
            
            % Numerical integration using Gauss-Kronrod adaptive quadrature
            %W_nm(i + 1,j + 1)     = (1/2)*quadgk(@(psi) (psi.^j).*f_legendre_pol(i,cos(psi),'current').*sin(psi),psi_1,psi_2);
            
        end
        
    end
    
end

if strcmp(out_m,'current')
    
    W_nm                          = W_nm(:,m + 1);
    
else
    
    W_nm                          = W_nm(1:n_max + 1,1:m + 1);
    
end

W_nm                              = double(W_nm);

end

function [G] = f_cov_askey_sh(n_max,psi_0,t,method,method_par)
%%
% F_COV_ASKEY_SH returns the spherical harmonic coefficients of the
% Askey covariance model. For more information, see:
%
% Piretzidis D, Kotsakis C, Mertikas SP, Sideris MG: Spherical harmonic
%      coefficients of isotropic polynomial functions with applications to
%      gravity field modeling
%
% HOW: [G] = f_cov_askey_sh(n_max,psi_0,t,method,method_par)
%
% Input:  n_max           [1 x 1] maximum degree.
%
%         psi_0           [1 x 1] range [rad].
%
%         t               [1 x 1] shape parameter.
%
%         method                  calculation method. Options:
%                                 -'r'       (default) recurrent.
%                                 -'n'                 numerical.
%                                 -'h'                 hybrid.
%                                 -'e'                 extended precision.
%
%         method_par      [1 x 1] method-specific parameter. For the
%                                 following methods, it denotes:
%                                 -'h' maximum degree of coefficients
%                                      calculated using numerical
%                                      integration. Default is 2.
%                                 -'e' number of significant digits.
%
% Output: G               [n x 1] spherical harmonic coefficients.
%
% Dimitrios Piretzidis, Space Geomatica P.C.
% 2022

% required m-files: f_ltpsim.m

%% Revision history

%% Remarks

%% Input check

if nargin < 3 || nargin > 5         ; error('Wrong number of input arguments.'); end
if nargin == 4 && strcmp(method,'r'); method_par = []                          ; end
if nargin == 4 && strcmp(method,'n'); method_par = n_max                       ; end
if nargin == 4 && strcmp(method,'h'); method_par = 1                           ; end
if nargin == 3                      ; method     = 'r'; method_par = []        ; end

if ~isscalar(n_max)
    error('<n_max> should be a scalar.')
end

if ~isscalar(psi_0)
    error('<psi_0> should be a scalar.')
end

if ~isscalar(t) || t ~= floor(t)
    error('<t> should be a scalar integer.')
end

if psi_0 <=0
    warning('<psi_0> should be greater than zero.')
end

if t < 2
    warning('<t> should be greater than or equal to 2.')
end

%% Start the algorithm

% Calculate spherical harmonic coefficients of monomials up to order <t>
PSI_nm = f_ltpsim(0,min(psi_0,pi),n_max,t,'all',method,method_par);

% Initialize covariance function coefficients
G      = zeros(n_max + 1,1);

% Calculate covariance function coefficients
for m = 0:t
    
    G  = G + (-1)^m * nchoosek(t,m) * (psi_0)^(-m) * PSI_nm(:,m + 1);
    
end
